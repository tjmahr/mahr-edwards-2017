
#' Helper functions for working with L2T's MySQL database
#' @name L2TDatabase
#' @docType package
#' @import dplyr RMySQL assertthat readr
#' @importFrom lubridate ymd as.period interval year month day
#' @importMethodsFrom lubridate %/%
NULL

# require("readxl")
# require("stringr")
# require("readr")
# require("dplyr", warn.conflicts = FALSE)
# require("RMySQL")
# require("assertthat")
# require("lubridate")
