library(testthat)
library(L2TDatabase)

test_check("L2TDatabase")
