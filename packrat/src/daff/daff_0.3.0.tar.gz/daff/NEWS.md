0.3.0
- Lots of improvements thanks to @gwarnes-mdsol
- 'render_diff' now defaults to 'pretty=TRUE'.
- Use inline CSS instead of obsolete '<center>' tag.
- Improve Output Formatting and Add Support for Daff Flags
- Update daff.js to version 1.3.25.

0.2.1
- added summary for patch, thanks to @jsta, feature request #12

0.2.0
- updated daff.js library to 1.3.16, thanks to @jeroenooms, solves issue #9

0.1.3
- changed internal I() into JS() thanks to @jeroenooms

0.1.2
- fixed issue #5 handling NA's, thanks to @eusebe
- removed the R version dependency (is dependent on V8)

0.1.1
- initial version
