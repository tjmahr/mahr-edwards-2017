`%||%` <- function(left, right){
  if (!is.null(left)){
    return(left)
  }
  right
}
