library(testthat)
library(daff)

test_check("daff")
