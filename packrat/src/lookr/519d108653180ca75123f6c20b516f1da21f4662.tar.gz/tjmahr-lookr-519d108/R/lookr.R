#' lookr.
#'
#' @docType package
#' @name lookr
#' @import stringr plyr tools
#' @importFrom stats poly setNames
#' @importFrom utils read.delim str write.csv
NULL

# require("tools")
# require("stringr")
# require("plyr")
# require("lubridate", warn.conflicts = FALSE)
