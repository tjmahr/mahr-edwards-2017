library("testthat")
library("lookr")

test_check("lookr")
