library(testthat)
library(polypoly)

test_check("polypoly")
