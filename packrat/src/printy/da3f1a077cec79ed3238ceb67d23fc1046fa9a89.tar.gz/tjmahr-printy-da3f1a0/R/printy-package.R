#' printy.
#'
#' @name printy
#' @docType package
NULL
