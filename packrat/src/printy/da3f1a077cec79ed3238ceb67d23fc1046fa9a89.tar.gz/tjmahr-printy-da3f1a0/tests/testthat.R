library(testthat)
library(printy)

test_check("printy")
