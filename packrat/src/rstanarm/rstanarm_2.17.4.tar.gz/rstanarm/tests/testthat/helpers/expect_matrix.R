expect_matrix <- function(x) expect_identical(class(x), "matrix")
