library(testthat)
library(rstantools)

foo <- function(x) {"test function"}

test_check("rstantools")
