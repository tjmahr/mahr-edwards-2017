library(testthat)
library(tristan)

test_check("tristan")
